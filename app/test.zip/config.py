DB_HOST = 'ds119523.mlab.com'

DB_PORT = 19523

DB_NAME = 'arrangement_db'

DB_USER = 'arrangement_user'

DB_PASS = 'arrangement_9pass'

# collections

SNAPSHOT = "snapshot"

ITEM = "item"

CONTAINER = "container"

ARRANGEMENT = "arrangement"